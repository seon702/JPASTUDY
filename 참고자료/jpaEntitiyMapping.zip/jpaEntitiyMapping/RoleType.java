package jpaEntitiyMapping;
public enum RoleType {
    USER, ADMIN, GUEST
}
